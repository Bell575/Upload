module.exports = {
  BOT_TOKEN: "7706993899:AAH44yDryhiMaB2i91nuJEYBBRB47oedMWk",
    allowedDevelopers: ['6138007734'], // ID
};